class WorkoutPlan {
  const WorkoutPlan({
    required this.id,
    required this.name,
    required this.focus,
    this.exerciseCount = 0,
  });

  final String id;
  final String name;
  final String focus;
  final int exerciseCount;
}